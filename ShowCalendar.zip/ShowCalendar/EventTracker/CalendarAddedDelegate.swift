protocol CalendarAddedDelegate {
    func calendarDidAdd()
}