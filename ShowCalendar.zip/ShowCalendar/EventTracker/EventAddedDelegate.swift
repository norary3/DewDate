protocol EventAddedDelegate {
    func eventDidAdd()
}