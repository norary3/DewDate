//
//  SegueConstants.swift
//  EventTracker
//
//  Created by Andrew Bancroft on 4/26/16.
//  Copyright © 2016 Andrew Bancroft. All rights reserved.
//

import Foundation

struct SegueIdentifiers {
    static let showAddCalendarSegue = "showAddCalendar"
    static let showEventsSegue = "showEvents"
}